module.exports = {
  dialect:'postgres',
  host:'localhost',
  username:'postgres',
  password: 'estudo',
  database:'consys',
  define:{
    timestamps: true,
    underscored: true,

  },
};